import random
import agentPSO
import jack
import multiprocessing as mp
import matplotlib.pyplot as plt
import numpy as np

def winrate(agent):
    return agent.winrate

class PSO():

    def __init__(self):
        self.p_upperBounds = [0 for x in range(408)]
        self.p_lowerBounds = [-0.5 for x in range(408)]
        self.n = 50
        self.gen = 50
        self.agentList = []
        self.g_best = None
        self.win_best = 0
        self.vel_const = 0.5
        self.bestWinrates = []
        self.allWinrates = []

    def randomInit(self):
        for agent in self.agentList:
            agent.randomInit(self.p_upperBounds, self.p_lowerBounds)
            agent.convertToStates(self.p_upperBounds)

    def pso(self):
        #initialization
        self.agentList = [agentPSO.AgentPSO() for x in range(self.n)]
        self.allWinrates = [[] for x in range(self.gen)]

        #set the upper bounds for the search space for each dimension based on the amount of actions possible
        #in the state associated with it
        for i in range (len(self.agentList[0].states)):
            for j in range(len(self.agentList[0].states[i])):
                self.p_upperBounds[len(self.agentList[0].states[i]) * i + j] = len(self.agentList[0].states[i][j]) + 0.5

        for k in range(len(self.agentList[0].splitStates)):
            for l in range(len(self.agentList[0].splitStates[k])):
                self.p_upperBounds[len(self.agentList[0].splitStates) * k + l + len(self.agentList[0].states) * len(self.agentList[0].states[0])] = len(self.agentList[0].splitStates[k][l]) + 0.5
        self.randomInit()

        #main loop
        for i in range (self.gen):
            print("Training Gen: " + str(i), end="\r")
            #----------------multiprocessing------------------
            #using the amount of cpu cores available on this machine - 2 (to ensure other processes can run simultaniously)
            with mp.Pool(mp.cpu_count() - 2) as p:
                self.agentList = p.map(jack.game, self.agentList)
            #-------------------------------------------------

            for agent in self.agentList:
                agent.calcWinrate()
                self.allWinrates[i].append(agent.winrate)

            self.agentList.sort(key=winrate, reverse=True)
            if self.agentList[0].winrate > self.win_best:
                self.win_best = self.agentList[0].winrate
                self.g_best = self.agentList[0].p_vec
            
            print("Gen " + str(i) +" Best Agent: " + str("{:.2f}".format(self.agentList[0].winrate)) + "%")
            self.bestWinrates.append(self.agentList[0].winrate)
            self.agentList[0].createSplitTable(i, "PSO", "")
            self.agentList[0].createTable(i, "PSO", "")
            #print(self.agentList[0].states)
            #print(self.agentList[0].p_vec)

            #update velocity and position of each agent
            for agent in self.agentList:
                agent.update(self.g_best, self.vel_const, self.p_lowerBounds, self.p_upperBounds)
                agent.reset()
        self.createLearningCurve()
        return self.agentList[0]
            
    def createLearningCurve(self):
        x = np.arange(1,len(self.bestWinrates)+1,1)
        averageWinrate = []
        minWinrate = []
        #print(self.allWinrates)
        for i in range(len(self.allWinrates)):
            minWinrate.append(min(self.allWinrates[i]))
            averageWinrate.append(sum(self.allWinrates[i]) / len(self.allWinrates[i]))
            
        line1, = plt.plot(x, minWinrate, color="black", label="Worst")    
        line2, = plt.plot(x, averageWinrate, color="blue", label="Average")    
        line3, = plt.plot(x, self.bestWinrates, color="red", label="Best")
        plt.legend(handles=[line3, line2, line1], loc=4)
        plt.ylim([20,45])
        plt.xlim([0,len(self.bestWinrates)])
        plt.ylabel("Winrate (%)")
        plt.xlabel("Generation")
        plt.title("Learning curve of a PSO playing blackjack (" + str(self.agentList[0].epochs) + " epochs per gen)")
        plt.grid(True)
        plt.savefig("learningcurvePSO.png")
        plt.close()